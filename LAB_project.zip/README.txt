Nama Kelompok : Bebas

Anggota Kelompok :
Nama				NIM
Salman Halim Razak		2802504724
Muhammad Athar			2802539141

Bite and Beware
Di dalam game ini terdapat ular yang tujuannya untuk memperpanjang ekornya
tetapi dalam perjalanan untuk memperbesar dirinya terdapat banyak jebakan 
yang membuat dia menjadi kesulitan dalam perjalanannya. semakin jauh
perjalanannya semakin banyak jebakan di dalam labirin tersebut.

Note : Masih belum selesai(belum ada jebakan, highscore, dll)